package br.com.robertoxavier.dto.lotacao;

public record LotacaoRequest() {
}
