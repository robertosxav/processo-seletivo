package br.com.robertoxavier.dto.cidade;

public record CidadeRequest(
        String cidNome,
        String cidUf
) {
}
