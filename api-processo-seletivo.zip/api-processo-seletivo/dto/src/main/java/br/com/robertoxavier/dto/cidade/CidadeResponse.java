package br.com.robertoxavier.dto.cidade;

public record CidadeResponse(
    Long id,
    String cidNome,
    String cidUf
){
}
