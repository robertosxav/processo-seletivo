package br.com.robertoxavier;

public enum Direction {
    ASC,
    DESC;

    private Direction() {
    }
}
