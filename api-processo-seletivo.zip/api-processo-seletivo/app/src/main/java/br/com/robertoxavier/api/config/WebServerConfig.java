package br.com.robertoxavier.api.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("br.com.robertoxavier")
public class WebServerConfig {
}
